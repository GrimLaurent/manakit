//  <Toolbar className={'mb-4'}>
//             <ToolbarTitle>Toolbar</ToolbarTitle>
//           </Toolbar>
//           <Toolbar className={'mb-4'} dense>
//             <ToolbarTitle>Toolbar dense</ToolbarTitle>
//           </Toolbar>
//           <Toolbar className={'mb-4'} flat>
//             Toolbar flat
//           </Toolbar>
//           <Toolbar className={'mb-4'} outlined>
//             Toolbar outlined
//           </Toolbar>
//           {/* <Toolbar className={'mb-4'} absolute>
//             Toolbar absolute
//           </Toolbar> */}
//           <Toolbar className={'mb-4'} elevation={4}>
//             Toolbar elevation 4 number
//           </Toolbar>
//           <Toolbar className={'mb-4'} elevation={'8'}>
//             Toolbar elevation 8 string
//           </Toolbar>
//           <Toolbar className={'mb-4'} rounded>
//             Toolbar rounded
//           </Toolbar>
//           <Toolbar className={'mb-4'} rounded={'lg'} style={{ background: 'red' }}>
//             Toolbar rounded md
//           </Toolbar>
//           <Toolbar className={'mb-4'} shaped>
//             Toolbar shaped
//           </Toolbar>
//           <Toolbar className={'mb-4'} tile>
//             Toolbar tile
//           </Toolbar>
//           <Toolbar className={'mb-4'} bottom>
//             Toolbar bottom
//           </Toolbar>
//           <Toolbar className={'mb-4'} floating>
//             Toolbar floating
//           </Toolbar>
