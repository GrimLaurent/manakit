const Manakit = {
  theme: {
    themes: {
      light: {
        // primary: 'pink',
        hello: '#fbbc07',
        // background: '#fffbfe',
        text: '#36393f',
        surface: '#ffffff',
      },
      dark: {
        bite: 'pink',
        // background: '#36393f',
        text: '#fffbfe',
      },
    },
  },
};

export default Manakit;
