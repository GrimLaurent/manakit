import common from './common.json';

const allTranslateFrFr = Object.assign({}, common);

export default allTranslateFrFr;
