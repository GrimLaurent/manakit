import common from './common.json';

const allTranslateEnUs = Object.assign({}, common);

export default allTranslateEnUs;
